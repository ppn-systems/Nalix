# Serializer Comparison Benchmarks

Latest benchmark snapshot for `Nalix.Benchmark.Framework.Serialization.SerializerComparisonBenchmarks`.

## Environment
- BenchmarkDotNet: `0.15.8`
- OS: Windows 11 `10.0.26200.8117`
- CPU: 13th Gen Intel Core i7-13620H (10C/16T)
- Runtime: .NET `10.0.5` (X64 RyuJIT, Server GC)
- SDK: .NET SDK `10.0.201`
- Job config: `IterationCount=15`, `LaunchCount=3`, `WarmupCount=10`, `RunStrategy=Throughput`

## Results
| Method | ItemCount | Mean | Error | StdDev | Median | Min | Max | P95 | Ratio | RatioSD | Rank | Gen0 | Gen1 | Gen2 | Allocated | Alloc Ratio |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| LiteSerializer Serialize | 16 | 148.4 ns | 26.02 ns | 47.59 ns | 119.4 ns | 117.0 ns | 253.1 ns | 241.6 ns | 1.08 | 0.44 | 1 | 0.0041 | - | - | 152 B | 1.00 |
| LiteSerializer Deserialize | 16 | 165.0 ns | 14.41 ns | 27.41 ns | 170.0 ns | 110.2 ns | 206.4 ns | 202.3 ns | 1.20 | 0.35 | 2 | 0.0105 | - | - | 392 B | 2.58 |
| MessagePack Serialize | 16 | 175.7 ns | 11.43 ns | 21.74 ns | 172.5 ns | 130.8 ns | 220.5 ns | 210.2 ns | 1.28 | 0.34 | 2 | 0.0033 | - | - | 128 B | 0.84 |
| MessagePack Deserialize | 16 | 358.0 ns | 12.66 ns | 23.78 ns | 356.9 ns | 286.0 ns | 395.0 ns | 389.7 ns | 2.61 | 0.64 | 3 | 0.0100 | - | - | 392 B | 2.58 |
| System.Text.Json Serialize | 16 | 480.2 ns | 32.16 ns | 60.41 ns | 472.9 ns | 377.2 ns | 604.2 ns | 595.0 ns | 3.50 | 0.94 | 4 | 0.0191 | - | - | 496 B | 3.26 |
| System.Text.Json Deserialize | 16 | 1,029.2 ns | 42.94 ns | 79.60 ns | 1,039.8 ns | 808.5 ns | 1,194.1 ns | 1,134.7 ns | 7.49 | 1.87 | 5 | 0.0305 | - | - | 1168 B | 7.68 |
| MessagePack Serialize | 128 | 262.0 ns | 8.19 ns | 15.58 ns | 263.6 ns | 227.5 ns | 302.7 ns | 280.5 ns | 0.90 | 0.15 | 1 | 0.0062 | - | - | 240 B | 0.40 |
| LiteSerializer Deserialize | 128 | 273.1 ns | 9.21 ns | 17.52 ns | 274.4 ns | 241.0 ns | 317.2 ns | 298.9 ns | 0.93 | 0.16 | 1 | 0.0224 | - | - | 840 B | 1.40 |
| LiteSerializer Serialize | 128 | 298.2 ns | 21.33 ns | 40.58 ns | 305.0 ns | 187.5 ns | 386.2 ns | 348.9 ns | 1.02 | 0.21 | 1 | 0.0160 | - | - | 600 B | 1.00 |
| MessagePack Deserialize | 128 | 851.4 ns | 43.31 ns | 81.34 ns | 859.9 ns | 655.2 ns | 981.7 ns | 958.2 ns | 2.91 | 0.53 | 2 | 0.0219 | - | - | 840 B | 1.40 |
| System.Text.Json Serialize | 128 | 1,266.8 ns | 45.26 ns | 85.00 ns | 1,261.8 ns | 1,111.8 ns | 1,505.0 ns | 1,393.4 ns | 4.34 | 0.73 | 3 | 0.0229 | - | - | 856 B | 1.43 |
| System.Text.Json Deserialize | 128 | 3,695.8 ns | 135.11 ns | 257.06 ns | 3,689.9 ns | 3,196.6 ns | 4,159.5 ns | 4,025.4 ns | 12.65 | 2.14 | 4 | 0.0687 | - | - | 2584 B | 4.31 |
| LiteSerializer Deserialize | 1024 | 1,048.9 ns | 37.21 ns | 70.80 ns | 1,073.8 ns | 829.6 ns | 1,142.4 ns | 1,132.3 ns | 0.87 | 0.09 | 1 | 0.1202 | - | - | 4424 B | 1.06 |
| LiteSerializer Serialize | 1024 | 1,218.9 ns | 45.81 ns | 87.16 ns | 1,238.7 ns | 967.6 ns | 1,387.8 ns | 1,338.0 ns | 1.01 | 0.10 | 2 | 0.1135 | - | - | 4184 B | 1.00 |
| MessagePack Serialize | 1024 | 3,374.9 ns | 278.02 ns | 528.97 ns | 3,366.1 ns | 1,964.8 ns | 4,423.5 ns | 4,176.0 ns | 2.78 | 0.48 | 3 | 0.0763 | - | - | 2800 B | 0.67 |
| MessagePack Deserialize | 1024 | 5,246.8 ns | 394.16 ns | 749.93 ns | 5,172.3 ns | 3,824.3 ns | 7,664.4 ns | 6,552.1 ns | 4.33 | 0.69 | 4 | 0.1755 | 0.0038 | 0.0038 | - | 0.00 |
| System.Text.Json Serialize | 1024 | 7,598.0 ns | 350.86 ns | 659.00 ns | 7,546.9 ns | 5,810.6 ns | 8,804.3 ns | 8,507.1 ns | 6.27 | 0.72 | 5 | 0.1144 | - | - | 4464 B | 1.07 |
| System.Text.Json Deserialize | 1024 | 21,782.2 ns | 2,330.45 ns | 4,319.63 ns | 23,762.7 ns | 14,923.6 ns | 28,567.1 ns | 26,377.2 ns | 17.97 | 3.78 | 6 | 0.3510 | - | - | 13408 B | 3.20 |
